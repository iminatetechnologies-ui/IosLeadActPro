export default {
    SPLASH: 'Splash',
    LOGIN: 'Login',
    HOME:'Home',
    LISTING:'Listing',
    TOOLS:'Tools',
    CONTACT:'Contact',
    ADDCONTACT:'AddContact',
  };
  