export const IMAGE_PATH = {
        LOGO: require("./../assets/images/logo.png"),
        AVTAR: require("./../assets/images/profile.png"),
        // Logo1: require("./../assets/images/mainlogo.png"),
        // HomeBack: require("./../assets/images/loginback.jpeg"),
        

       
}